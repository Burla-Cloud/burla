### How to test the main service

This service has no test suite,  
To test it we run the integration tests in the burla client (the python package).  
See `client/tests/README.md` for instructions to run these tests.
