import pickle
import json
import psutil
from time import time
from queue import Empty
from typing import Optional

import asyncio
import aiohttp
from google.cloud import firestore
from google.cloud.firestore_v1.async_client import AsyncClient
from fastapi import APIRouter, Path, Depends, Response, Request

from node_service import (
    SELF,
    PROJECT_ID,
    INSTANCE_NAME,
    get_request_json,
    get_logger,
    get_request_files,
)
from node_service.helpers import Logger
from node_service.job_watcher import send_inputs_to_workers, job_watcher_logged

router = APIRouter()


@router.get("/jobs/{job_id}/inputs")
async def get_inputs(job_id: str = Path(...), logger: Logger = Depends(get_logger)):
    if job_id != SELF["current_job"]:
        return Response("job not found", status_code=404)
    elif SELF["SHUTTING_DOWN"]:
        return Response("Node is shutting down, can't give inputs.", status_code=410)

    min_reply_size_bytes = 1_000_000 * 0.5
    min_reply_size_per_worker = min_reply_size_bytes / len(SELF["workers"])

    async def _get_inputs_from_worker(session, worker):
        try:
            url = f"{worker.url}/jobs/{job_id}/inputs?min_reply_size={min_reply_size_per_worker}"
            async with session.get(url, timeout=1) as response:
                response.raise_for_status()
                if response.status == 200:
                    return pickle.loads(await response.read())
                elif response.status == 204:
                    return []
        except Exception as e:
            msg = f"Failed to get inputs from worker {worker.container_name} for job {job_id}: {e}"
            logger.log(msg, severity="WARNING")
            return []

    async with aiohttp.ClientSession() as session:
        tasks = [_get_inputs_from_worker(session, w) for w in SELF["workers"]]
        inputs = [input for inputs in await asyncio.gather(*tasks) for input in inputs]

    if not inputs:
        return Response(status_code=204)
    else:
        logger.log(f"Sending {len(inputs)} inputs to another node!")
        data = pickle.dumps(inputs)
        await asyncio.sleep(0)
        headers = {"Content-Disposition": 'attachment; filename="inputs.pkl"'}
        return Response(content=data, media_type="application/octet-stream", headers=headers)


@router.post("/jobs/{job_id}/inputs/done")
async def input_upload_done(job_id: str = Path(...)):
    """
    This simply allows the node to conclude that is is done (in job_watcher).
    Unless it explicitly hears that no more inputs are coming after getting some, it won't
    consider itself done.
    """
    if job_id != SELF["current_job"]:
        return Response("job not found", status_code=404)
    SELF["all_inputs_uploaded"] = True


@router.post("/jobs/{job_id}/inputs")
async def upload_inputs(
    job_id: str = Path(...),
    request_files: Optional[dict] = Depends(get_request_files),
):
    if SELF["pending_inputs"]:
        return Response("No space for more inputs! retry later.", status_code=409)
    if job_id != SELF["current_job"]:
        return Response("job not found", status_code=404)
    elif SELF["SHUTTING_DOWN"]:
        return Response("Node is shutting down, inputs not accepted.", status_code=410)

    # needs to be here so this is reset when transferring from another dying node
    SELF["current_input_batch_forwarded"] = False
    SELF["all_inputs_uploaded"] = False

    inputs_pkl_with_idx = pickle.loads(request_files["inputs_pkl_with_idx"])
    await asyncio.sleep(0)
    async with aiohttp.ClientSession() as session:
        # rejected = no space to store
        rejected_inputs_pkl_with_idx = await send_inputs_to_workers(session, inputs_pkl_with_idx)
        # is emptied from the job_watcher thread, no more inputs accepted until it's empty
        SELF["pending_inputs"] = rejected_inputs_pkl_with_idx

    SELF["current_input_batch_forwarded"] = True


@router.get("/jobs/{job_id}/results")
async def get_results(job_id: str = Path(...)):
    if job_id != SELF["current_job"]:
        print(f"job {job_id} not found, current job: {SELF['current_job']}")
        return Response("job not found", status_code=404)

    results = []
    total_bytes = 0
    while (not SELF["results_queue"].empty()) and (total_bytes < (1_000_000 * 0.5)):
        try:
            result = SELF["results_queue"].get_nowait()
            results.append(result)
            total_bytes += len(result[2])
        except Empty:
            break

    await asyncio.sleep(0)
    response_json = {
        "results": results,
        "current_parallelism": SELF["current_parallelism"],
        "is_empty": SELF["results_queue"].empty(),
        "currently_installing_package": SELF["currently_installing_package"],
    }

    if SELF["udf_start_latency"] and not SELF["udf_start_latency_sent_to_client"]:
        response_json["udf_start_latency"] = SELF["udf_start_latency"]
        SELF["udf_start_latency_sent_to_client"] = True
    if SELF["packages_to_install"] and not SELF["packages_to_install_sent_to_client"]:
        response_json["packages_to_install"] = SELF["packages_to_install"]
        SELF["packages_to_install_sent_to_client"] = True
    if SELF["all_packages_installed"] and not SELF["all_packages_installed_sent_to_client"]:
        response_json["all_packages_installed"] = SELF["all_packages_installed"]
        SELF["all_packages_installed_sent_to_client"] = True

    data = pickle.dumps(response_json)
    await asyncio.sleep(0)
    headers = {"Content-Disposition": 'attachment; filename="results.pkl"'}
    return Response(content=data, media_type="application/octet-stream", headers=headers)


@router.post("/jobs/{job_id}")
async def execute(
    request: Request,
    job_id: str = Path(...),
    request_json: dict = Depends(get_request_json),
    request_files: Optional[dict] = Depends(get_request_files),
    logger: Logger = Depends(get_logger),
):
    logger.log(f"Executing job {job_id} ...")
    # The `on_job_start` function in __init__.py is run as soon as upload to this endpoint starts.
    # It exists to set `SELF["current_job"]` and set this node to RUNNING in the db as soon as
    # upload starts if the user's function is big.

    # determine which workers to call
    workers_to_assign = []
    workers_to_leave_idle = []
    future_parallelism = 0
    is_background_job = request_json["is_background_job"]
    user_python_version = request_json["user_python_version"]

    # move the installer worker to the front of the list so it's DEFINITELY included in the
    # set of selected workers if there are any (otherwise unable to install packages)
    installer_worker = [w for w in SELF["workers"] if w.elected_installer][0]
    SELF["workers"].remove(installer_worker)
    SELF["workers"] = [installer_worker, *SELF["workers"]]

    for worker in SELF["workers"]:
        correct_python_version = worker.python_version == user_python_version
        need_more_parallelism = future_parallelism < request_json["parallelism"]

        if correct_python_version and need_more_parallelism:
            workers_to_assign.append(worker)
            future_parallelism += 1
        else:
            workers_to_leave_idle.append(worker)

    if not workers_to_assign:
        # possible the `on_job_start` in __init__ hasn't run yet because async.
        # if it runs after this returns node will be stuck running.
        # switch coroutines until this node is running, then reset back.
        # using async in `on_job_start` because it's maybe slightly faster ?
        n = 0
        while not SELF["RUNNING"]:
            n += 1
            if n > 10:
                raise Exception("this is theoretically impossible")
            await asyncio.sleep(0)

        SELF["RUNNING"] = False
        SELF["current_job"] = None
        async_db = AsyncClient(project=PROJECT_ID, database="burla")
        node_doc = async_db.collection("nodes").document(INSTANCE_NAME)
        await node_doc.update({"status": "READY", "current_job": None})

        msg = "No compatible containers.\n"
        msg += f"User is running python version {user_python_version}, "
        versions = list(set([e.python_version for e in SELF["workers"]]))
        msg += f"containers in the cluster are running: {', '.join(versions)}.\n"
        msg += "To fix this you can either:\n"
        msg += f" - update the cluster to run containers with python{user_python_version}\n"
        msg += f" - update your local python version to be one of {versions}"
        return Response(msg, status_code=409)

    # RAM limits on input/output queues prevent worker/node-service from getting fucked
    IO_RAM_TO_TOTAL_RAM_RATIO = 0.75  # percent of total ram input/output queues allowed to use
    NODE_TO_WORKER_IO_RAM_RATIO = 2  # node-service io queues can use 2x the ram of worker queues
    io_ram_limit_gb = (psutil.virtual_memory().total / 1024**3) * IO_RAM_TO_TOTAL_RAM_RATIO
    worker_io_ram_limit_gb = io_ram_limit_gb / (
        len(workers_to_assign) + NODE_TO_WORKER_IO_RAM_RATIO
    )
    # This isn't a limit, it can be exceeded
    # The node svc just dosen't ask for more results when it's over this size.
    SELF["return_queue_ram_threshold_gb"] = worker_io_ram_limit_gb * NODE_TO_WORKER_IO_RAM_RATIO
    # logger.log(f"set return_queue_ram_threshold_gb to {SELF['return_queue_ram_threshold_gb']}")

    async def assign_worker(session, worker):
        data = aiohttp.FormData()
        packages_json = json.dumps(
            {
                "start_time": request_json["start_time"],
                "packages": request_json["packages"],
                "io_queues_ram_limit_gb": worker_io_ram_limit_gb,
            }
        )
        data.add_field("function_pkl", request_files["function_pkl"])
        data.add_field("request_json", packages_json, content_type="application/json")

        async with session.post(f"{worker.url}/jobs/{job_id}", data=data) as response:
            if response.status == 200:
                return worker
            elif response.status == 500:
                logs = worker.logs() if worker.exists() else "Unable to retrieve container logs."
                error_title = f"Worker {worker.container_name} returned status {response.status}!"
                msg = f"{error_title} Logs from container:\n{logs.strip()}"
                firestore_client = firestore.Client(project=PROJECT_ID, database="burla")
                node_ref = firestore_client.collection("nodes").document(INSTANCE_NAME)
                node_ref.collection("logs").document().set({"msg": msg, "ts": time()})
                logger.log(msg, severity="WARNING")
                return None
            else:
                msg = f"Worker {worker.container_name} returned error: {response.status}"
                logger.log(msg, severity="WARNING")
                return None

    async with aiohttp.ClientSession() as session:
        tasks = [assign_worker(session, worker) for worker in workers_to_assign]
        successfully_assigned_workers = [w for w in await asyncio.gather(*tasks) if w is not None]

    if len(successfully_assigned_workers) == 0:
        raise Exception("Failed to assign job to any workers")

    SELF["workers"] = workers_to_assign
    SELF["idle_workers"] = workers_to_leave_idle

    SELF["job_watcher_stop_event"].clear()  # is initalized as set by default
    job_watcher_coroutine = job_watcher_logged(
        request_json["n_inputs"], is_background_job, request.headers
    )
    SELF["job_watcher_task"] = asyncio.create_task(job_watcher_coroutine)
